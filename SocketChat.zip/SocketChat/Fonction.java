
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Fonction {
	String calcul;
	String typeCalcul;
	String calculFile;
	int taille;
	static String urlRacine = "D:/Bosy Steven/S3/Projet Socket Vahatra/Service - Final/File";

	calcul(){
		File fichier = new File(urlRacine);
            if(!fichier.exists()){
                  fichier.mkdir();
            }
	}

	calcul(String cal)  throws RequeteInvalideException, RequeteNullException, FinSessionException { 
            
            File fichier = new File(urlRacine);
            if(!fichier.exists()){
                  fichier.mkdir();
            }
            if(cal.equalsIgnoreCase("")||(cal == null)){
                  throw new calueteNullException("erreur");
            }
            this.cal = cal;
            if(cal.equalsIgnoreCase("END SESSION")){
                  throw new FinSessionException("bye");
            }
            String[] calSep = cal.split(" ");
            taille = calSep.length;
            if((taille!=2)&&(taille!=3)){
                  throw new RequeteInvalideException("erreur");
            }
            typeReq = calSep[0];
            reqTab = calSep[1];
            if(taille==3){
                  calculFile = calSep[2];
            }
            if(!(this.requeteValide())){
                  throw new RequeteInvalideException("erreur");
            }
      }

	String getCalcul(){
		return calcul;
	}

	String getTypeCalcul(){
		return typeCalcul;
	}

	String getCalFichier(){
		return calculFile;
	}

	int getTaille(){
		return taille;
	}


	boolean typeCalculValide(){
		String[] calculValide = new String[4];
		calculValide[0] = "SOMME";
		calculValide[1] = "MULTIPLICATION";
		calculValide[2] = "SOUSTRACTION";
		calculValide[3] = "DIVISION";
		calculValide[4] = "CREATE";
		calculValide[5] = "HISTORY";
		calculValide[6] = "DROP";
		for (int i=0;i<calculValide.length;i++ ) {
                  boolean condition = calculValide[i].equalsIgnoreCase(this.getTypeCalcul());
                  if(condition){
                        result = true;
                  }
            }
        boolean result=false;
            return result;
	}

	boolean isSOMME(){
            boolean result = typeReq.equalsIgnoreCase("SOMME");
            return result;
    }
      boolean isMULTIPLICATION(){
            boolean result = typeReq.equalsIgnoreCase("MULTIPLICATION");
            return result;
    }
      boolean isSOUSTRACTION(){
            boolean result = typeReq.equalsIgnoreCase("SOUSTRACTION");
            return result;
    }
    boolean isDIVISION(){
            boolean result = typeReq.equalsIgnoreCase("DIVISION");
            return result;
    }	

	boolean isCREATE(){
            boolean result = typeReq.equalsIgnoreCase("CREATE");
            return result;
    }

    boolean isHISTORY(){
            boolean result = typeReq.equalsIgnoreCase("HISTORY");
            return result;
    }

    boolean isDROP(){
            boolean result = typeReq.equalsIgnoreCase("DROP");
            return result;
    }    
    


    void create() throws TableUniqueException, RequeteInvalideException{
    	File f;
            String url = urlRacine+"/data.txt";
            f = new File(url);
            try {
                  f.createNewFile();
                  FileWriter fw = new FileWriter(url,true);
                  BufferedWriter bw = new BufferedWriter(fw);
                  bw.write(getCalFichier());
                  bw.newLine();
                  bw.write("************************");
                  bw.newLine();
                  bw.flush();
                  bw.close();
                  fw.close();
            } catch (IOException ex) {
                  Logger.getLogger(Requete.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    void insertInto() throws TableInexistantException, DataIncorrectException {

            if(tableInexistant()){
                throw new TableInexistantException(getTypeReq());
            }
            String[] rqDt = getReqData().split(" ");
            try {
                  String table = reqTab.toLowerCase();
                  String url = urlRacine+"/data.txt";
                  
                  File f = new File(url);
                  FileReader fr = new FileReader(f);
                  BufferedReader br = new BufferedReader(fr);
                  String line;
                  line = br.readLine();
                  String[] flr = line.split(" ");
                  if(flr.length!=rqDt.length){
                        throw new DataIncorrectException(getTypeReq());
                  }
                          
                  FileWriter fw = new FileWriter(url,true); 
                  BufferedWriter bw = new BufferedWriter(fw);
                  bw.newLine();
                  bw.write(getReqData());
                  bw.flush();
                  bw.close();
                  fw.close();
            } catch (IOException ex) {
                  Logger.getLogger(Requete.class.getName()).log(Level.SEVERE, null, ex);
            }
      }

}