import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;


public class Client {

  static String urlRacine = "D:/Bosy Steven/S3/Projet Socket Vahatra/Service - Final/File";
   public static void main(String[] args) {
      
     Socket clientSocket;
     BufferedReader in;
     PrintWriter out;
     Scanner sc = new Scanner(System.in);
  
      try {
         /*
         * les informations du serveur ( port et adresse IP ou nom d'hote
         * 127.0.0.1 est l'adresse local de la machine
         */
         clientSocket = new Socket("127.0.0.1",5000);
   
         //
         out = new PrintWriter(clientSocket.getOutputStream());
         //
         in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
   
         Thread envoyer = new Thread(new Runnable() {
             String msg;
              @Override
              public void run() {
                while(true){
                  msg = sc.nextLine();            
                  out.println(msg);
                  out.flush();
                }
             }
         });
         envoyer.start();
   
        Thread recevoir = new Thread(new Runnable() {
            String msg;
            @Override
            public void run() {
               try {
                 msg = in.readLine();
                 while(msg!=null){
                    File f;
                  String url = urlRacine+"/data.txt";
                  f = new File(url);
                  try {
                    f.createNewFile();
                    FileWriter fw = new FileWriter(url,true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write("Serveur: "+msg);
                    bw.newLine();
                    bw.write("************************");
                    bw.newLine();
                    bw.flush();
                    bw.close();
                    fw.close();
                  } catch (IOException e) {
                  e.printStackTrace();
                  }
                    System.out.println("Serveur : "+msg);
                    msg=in.readLine();
                   //break;
                 }
                 System.out.println("Serveur disconected");
                 out.close();
                 clientSocket.close();
                 
               } catch (IOException e) {
                   e.printStackTrace();
               }
            }
        });
        recevoir.start();
   
      } catch (IOException e) {
           e.printStackTrace();
      }
  }
}